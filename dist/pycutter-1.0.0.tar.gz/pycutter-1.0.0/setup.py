#! /usr/bin/env python

import os
from distutils.core import setup

setup (
	name='pycutter',
	version='1.0.0',
	scripts=['pycutter'],
	author='Bharath',
	author_email='bharath_ves@hotmail.com',
	description=' A simple URL Shortener',
)
